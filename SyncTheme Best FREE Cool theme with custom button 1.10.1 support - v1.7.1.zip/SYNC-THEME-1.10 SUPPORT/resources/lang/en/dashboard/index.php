<?php

return [
    'search' => 'Search for servers...',
    'no_matches' => 'There were no servers found matching the search criteria provided.',
    'cpu_title' => 'CPU',
    'memory_title' => 'Memory',
];
